import React from 'react'

const ContactUs = () => {
  return (

    <div style={{marginBottom:"380px"}} className="main btn4">
      <div className="row">
        <div className="col"></div>
        <div style={{ marginTop: "20px" }} className="col">
          <h3>Contact Us : </h3>
          <h5 style={{ marginTop: "10px" }} >Email : indian_rail@gamil.com</h5>
          <h5>Contact No : +91 9689684628</h5>
        </div>
        <div className="col"></div>
      </div>

    </div>
  )
}

export default ContactUs